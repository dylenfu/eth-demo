var Migrations = artifacts.require("./Migrations.sol");
module.exports = function (deployer) {
    deployer.deploy(Migrations);
};
//# sourceMappingURL=1_initial_migration.js.map