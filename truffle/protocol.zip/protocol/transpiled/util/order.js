"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const _ = require("lodash");
const ethUtil = require("ethereumjs-util");
const promisify = require("es6-promisify");
const crypto_1 = require("./crypto");
const web3Instance = web3;
class Order {
    constructor(owner, params) {
        this.owner = owner;
        this.params = params;
    }
    isValidSignature() {
        const { v, r, s } = this.params;
        if (_.isUndefined(v) || _.isUndefined(r) || _.isUndefined(s)) {
            throw new Error('Cannot call isValidSignature on unsigned order');
        }
        const orderHash = this.getOrderHash();
        //console.log("hash len:", orderHash.length.toString());
        const msgHash = ethUtil.hashPersonalMessage(orderHash);
        //console.log("msgHash:", ethUtil.bufferToHex(msgHash));
        try {
            const pubKey = ethUtil.ecrecover(msgHash, v, ethUtil.toBuffer(r), ethUtil.toBuffer(s));
            const recoveredAddress = ethUtil.bufferToHex(ethUtil.pubToAddress(pubKey));
            return recoveredAddress === this.owner;
        }
        catch (err) {
            return false;
        }
    }
    signAsync() {
        return __awaiter(this, void 0, void 0, function* () {
            const orderHash = this.getOrderHash();
            // console.log("order owner:", this.owner);
            // console.log("order hash:", ethUtil.bufferToHex(orderHash));
            const signature = yield promisify(web3Instance.eth.sign)(this.owner, ethUtil.bufferToHex(orderHash));
            const { v, r, s } = ethUtil.fromRpcSig(signature);
            this.params = _.assign(this.params, {
                orderHashHex: ethUtil.bufferToHex(orderHash),
                v,
                r: ethUtil.bufferToHex(r),
                s: ethUtil.bufferToHex(s),
            });
        });
    }
    getOrderHash() {
        const orderHash = crypto_1.crypto.solSHA3([
            this.params.loopringProtocol,
            this.owner,
            this.params.tokenS,
            this.params.tokenB,
            this.params.amountS,
            this.params.amountB,
            this.params.timestamp,
            this.params.ttl,
            this.params.salt,
            this.params.lrcFee,
            this.params.buyNoMoreThanAmountB,
            this.params.marginSplitPercentage,
        ]);
        return orderHash;
    }
}
exports.Order = Order;
//# sourceMappingURL=order.js.map