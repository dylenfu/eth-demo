"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const bignumber_js_1 = require("bignumber.js");
const bignumber_config_1 = require("./bignumber_config");
bignumber_config_1.bigNumberConfigs.configure();
exports.BNUtil = {
    add(numA, numB) {
        const a = new bignumber_js_1.BigNumber(numA);
        const b = new bignumber_js_1.BigNumber(numB);
        const result = a.plus(b);
        return result.toString();
    },
    sub(numA, numB) {
        const a = new bignumber_js_1.BigNumber(numA);
        const b = new bignumber_js_1.BigNumber(numB);
        const result = a.minus(b);
        return result.toString();
    },
    mul(numA, numB) {
        const a = new bignumber_js_1.BigNumber(numA);
        const b = new bignumber_js_1.BigNumber(numB);
        const result = a.times(b);
        return result.toString();
    },
    div(numA, numB, decimalPlaces = 18) {
        bignumber_js_1.BigNumber.config({
            DECIMAL_PLACES: decimalPlaces,
        });
        const a = new bignumber_js_1.BigNumber(numA);
        const b = new bignumber_js_1.BigNumber(numB);
        const result = a.div(b);
        return result.toString();
    },
    cmp(numA, numB) {
        const a = new bignumber_js_1.BigNumber(numA);
        const b = new bignumber_js_1.BigNumber(numB);
        return a.comparedTo(b);
    },
    toSmallestUnits(num, decimals = 18) {
        const a = new bignumber_js_1.BigNumber(num);
        const unit = new bignumber_js_1.BigNumber(10).pow(decimals);
        const result = a.times(unit);
        return result;
    },
};
//# sourceMappingURL=bn_util.js.map