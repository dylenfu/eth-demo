"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const bignumber_js_1 = require("bignumber.js");
const order_1 = require("./order");
const ring_1 = require("./ring");
//bigNumberConfigs.configure();
class RingFactory {
    constructor(loopringProtocolAddr, eosAddress, neoAddress, lrcAddress, qtumAddress, currBlockTimeStamp) {
        this.loopringProtocolAddr = loopringProtocolAddr;
        this.eosAddress = eosAddress;
        this.neoAddress = neoAddress;
        this.lrcAddress = lrcAddress;
        this.qtumAddress = qtumAddress;
        this.currBlockTimeStamp = currBlockTimeStamp;
    }
    generateSize2Ring01(order1Owner, order2Owner, ringOwner) {
        return __awaiter(this, void 0, void 0, function* () {
            const orderPrams1 = {
                loopringProtocol: this.loopringProtocolAddr,
                tokenS: this.eosAddress,
                tokenB: this.neoAddress,
                amountS: new bignumber_js_1.BigNumber(1000e18),
                amountB: new bignumber_js_1.BigNumber(100e18),
                timestamp: new bignumber_js_1.BigNumber(this.currBlockTimeStamp),
                ttl: new bignumber_js_1.BigNumber(360000),
                salt: new bignumber_js_1.BigNumber(1234),
                lrcFee: new bignumber_js_1.BigNumber(10e18),
                buyNoMoreThanAmountB: false,
                marginSplitPercentage: 0,
            };
            const orderPrams2 = {
                loopringProtocol: this.loopringProtocolAddr,
                tokenS: this.neoAddress,
                tokenB: this.eosAddress,
                amountS: new bignumber_js_1.BigNumber(100e18),
                amountB: new bignumber_js_1.BigNumber(1000e18),
                timestamp: new bignumber_js_1.BigNumber(this.currBlockTimeStamp),
                ttl: new bignumber_js_1.BigNumber(360000),
                salt: new bignumber_js_1.BigNumber(4321),
                lrcFee: new bignumber_js_1.BigNumber(5e18),
                buyNoMoreThanAmountB: false,
                marginSplitPercentage: 0,
            };
            const order1 = new order_1.Order(order1Owner, orderPrams1);
            const order2 = new order_1.Order(order2Owner, orderPrams2);
            yield order1.signAsync();
            yield order2.signAsync();
            const ring = new ring_1.Ring(ringOwner, [order1, order2]);
            yield ring.signAsync();
            return ring;
        });
    }
    generateSize2Ring02(order1Owner, order2Owner, ringOwner) {
        return __awaiter(this, void 0, void 0, function* () {
            const orderPrams1 = {
                loopringProtocol: this.loopringProtocolAddr,
                tokenS: this.eosAddress,
                tokenB: this.neoAddress,
                amountS: new bignumber_js_1.BigNumber(1000e18),
                amountB: new bignumber_js_1.BigNumber(100e18),
                timestamp: new bignumber_js_1.BigNumber(this.currBlockTimeStamp),
                ttl: new bignumber_js_1.BigNumber(360000),
                salt: new bignumber_js_1.BigNumber(1234),
                lrcFee: new bignumber_js_1.BigNumber(0),
                buyNoMoreThanAmountB: false,
                marginSplitPercentage: 100,
            };
            const orderPrams2 = {
                loopringProtocol: this.loopringProtocolAddr,
                tokenS: this.neoAddress,
                tokenB: this.eosAddress,
                amountS: new bignumber_js_1.BigNumber(50e18),
                amountB: new bignumber_js_1.BigNumber(450e18),
                timestamp: new bignumber_js_1.BigNumber(this.currBlockTimeStamp),
                ttl: new bignumber_js_1.BigNumber(360000),
                salt: new bignumber_js_1.BigNumber(4321),
                lrcFee: new bignumber_js_1.BigNumber(0),
                buyNoMoreThanAmountB: false,
                marginSplitPercentage: 45,
            };
            const order1 = new order_1.Order(order1Owner, orderPrams1);
            const order2 = new order_1.Order(order2Owner, orderPrams2);
            yield order1.signAsync();
            yield order2.signAsync();
            const ring = new ring_1.Ring(ringOwner, [order1, order2]);
            yield ring.signAsync();
            return ring;
        });
    }
    generateSize2Ring03(order1Owner, order2Owner, ringOwner) {
        return __awaiter(this, void 0, void 0, function* () {
            const orderPrams1 = {
                loopringProtocol: this.loopringProtocolAddr,
                tokenS: this.eosAddress,
                tokenB: this.neoAddress,
                amountS: new bignumber_js_1.BigNumber(1000e18),
                amountB: new bignumber_js_1.BigNumber(100e18),
                timestamp: new bignumber_js_1.BigNumber(this.currBlockTimeStamp),
                ttl: new bignumber_js_1.BigNumber(360000),
                salt: new bignumber_js_1.BigNumber(1234),
                lrcFee: new bignumber_js_1.BigNumber(0),
                buyNoMoreThanAmountB: true,
                marginSplitPercentage: 65,
            };
            const orderPrams2 = {
                loopringProtocol: this.loopringProtocolAddr,
                tokenS: this.neoAddress,
                tokenB: this.eosAddress,
                amountS: new bignumber_js_1.BigNumber(50e18),
                amountB: new bignumber_js_1.BigNumber(450e18),
                timestamp: new bignumber_js_1.BigNumber(this.currBlockTimeStamp),
                ttl: new bignumber_js_1.BigNumber(360000),
                salt: new bignumber_js_1.BigNumber(4321),
                lrcFee: new bignumber_js_1.BigNumber(5e17),
                buyNoMoreThanAmountB: false,
                marginSplitPercentage: 45,
            };
            const order1 = new order_1.Order(order1Owner, orderPrams1);
            const order2 = new order_1.Order(order2Owner, orderPrams2);
            yield order1.signAsync();
            yield order2.signAsync();
            const ring = new ring_1.Ring(ringOwner, [order1, order2]);
            yield ring.signAsync();
            return ring;
        });
    }
    generateSize3Ring01(order1Owner, order2Owner, order3Owner, ringOwner) {
        return __awaiter(this, void 0, void 0, function* () {
            const orderPrams1 = {
                loopringProtocol: this.loopringProtocolAddr,
                tokenS: this.eosAddress,
                tokenB: this.neoAddress,
                amountS: new bignumber_js_1.BigNumber(80000e18),
                amountB: new bignumber_js_1.BigNumber(12345e18),
                timestamp: new bignumber_js_1.BigNumber(this.currBlockTimeStamp),
                ttl: new bignumber_js_1.BigNumber(360000),
                salt: new bignumber_js_1.BigNumber(1234),
                lrcFee: new bignumber_js_1.BigNumber(0),
                buyNoMoreThanAmountB: true,
                marginSplitPercentage: 55,
            };
            const orderPrams2 = {
                loopringProtocol: this.loopringProtocolAddr,
                tokenS: this.neoAddress,
                tokenB: this.qtumAddress,
                amountS: new bignumber_js_1.BigNumber(234e18),
                amountB: new bignumber_js_1.BigNumber(543e18),
                timestamp: new bignumber_js_1.BigNumber(this.currBlockTimeStamp),
                ttl: new bignumber_js_1.BigNumber(360000),
                salt: new bignumber_js_1.BigNumber(4321),
                lrcFee: new bignumber_js_1.BigNumber(6e18),
                buyNoMoreThanAmountB: false,
                marginSplitPercentage: 0,
            };
            const orderPrams3 = {
                loopringProtocol: this.loopringProtocolAddr,
                tokenS: this.qtumAddress,
                tokenB: this.eosAddress,
                amountS: new bignumber_js_1.BigNumber(6780e18),
                amountB: new bignumber_js_1.BigNumber(18100e18),
                timestamp: new bignumber_js_1.BigNumber(this.currBlockTimeStamp),
                ttl: new bignumber_js_1.BigNumber(360000),
                salt: new bignumber_js_1.BigNumber(4321),
                lrcFee: new bignumber_js_1.BigNumber(0),
                buyNoMoreThanAmountB: false,
                marginSplitPercentage: 60,
            };
            const order1 = new order_1.Order(order1Owner, orderPrams1);
            const order2 = new order_1.Order(order2Owner, orderPrams2);
            const order3 = new order_1.Order(order3Owner, orderPrams3);
            yield order1.signAsync();
            yield order2.signAsync();
            yield order3.signAsync();
            const ring = new ring_1.Ring(ringOwner, [order1, order2, order3]);
            yield ring.signAsync();
            return ring;
        });
    }
    caculateRateAmountS(ring) {
        let rate = 1;
        let result = [];
        const size = ring.orders.length;
        for (let i = 0; i < size; i++) {
            const order = ring.orders[i];
            rate = rate * order.params.amountS.toNumber() / order.params.amountB.toNumber();
        }
        rate = Math.pow(rate, -1 / size);
        //rate = rate.toPrecision(12);
        //console.log("rate:", rate);
        for (let i = 0; i < size; i++) {
            const order = ring.orders[i];
            const rateAmountS = order.params.amountS.toNumber() * rate;
            const rateSBigNumber = new bignumber_js_1.BigNumber(rateAmountS.toPrecision(12));
            result.push(rateSBigNumber);
        }
        return result;
    }
    ringToSubmitableParams(ring, feeSelectionList, feeRecepient, throwIfLRCIsInsuffcient) {
        const ringSize = ring.orders.length;
        let addressList = [];
        let uintArgsList = [];
        let uint8ArgsList = [];
        let buyNoMoreThanAmountBList = [];
        let vList = [];
        let rList = [];
        let sList = [];
        const rateAmountSList = this.caculateRateAmountS(ring);
        //console.log("rateAmountSList", rateAmountSList);
        for (let i = 0; i < ringSize; i++) {
            const order = ring.orders[i];
            const addressListItem = [order.owner, order.params.tokenS];
            addressList.push(addressListItem);
            const uintArgsListItem = [
                order.params.amountS,
                order.params.amountB,
                order.params.timestamp,
                order.params.ttl,
                order.params.salt,
                order.params.lrcFee,
                rateAmountSList[i]
            ];
            uintArgsList.push(uintArgsListItem);
            const uint8ArgsListItem = [order.params.marginSplitPercentage, feeSelectionList[i]];
            //console.log("uint8ArgsListItem", uint8ArgsListItem);
            uint8ArgsList.push(uint8ArgsListItem);
            buyNoMoreThanAmountBList.push(order.params.buyNoMoreThanAmountB);
            vList.push(order.params.v);
            rList.push(order.params.r);
            sList.push(order.params.s);
        }
        vList.push(ring.v);
        rList.push(ring.r);
        sList.push(ring.s);
        const submitParams = {
            addressList: addressList,
            uintArgsList: uintArgsList,
            uint8ArgsList: uint8ArgsList,
            buyNoMoreThanAmountBList: buyNoMoreThanAmountBList,
            vList: vList,
            rList: rList,
            sList: sList,
            ringOwner: ring.owner,
            feeRecepient: feeRecepient,
            throwIfLRCIsInsuffcient: throwIfLRCIsInsuffcient
        };
        return submitParams;
    }
    caculateRingFeesAndBalances(ring, feeSelectionList) {
        const rateAmountSList = this.caculateRateAmountS(ring);
        let fillAmountSList = [];
        const size = ring.orders.length;
        // caculate fillAmountS, scale by smallest index.
        let smallestIndex = -1;
        for (let i = 0; i < size; i++) {
            const order = ring.orders[i];
            if (i == 0) {
                fillAmountSList.push(rateAmountSList[0].toNumber());
            }
            else {
                const fillAmountSMax = fillAmountSList[i - 1] * order.params.amountB.toNumber() / rateAmountSList[i - 1].toNumber();
                if (fillAmountSMax > order.params.amountS.toNumber()) {
                    smallestIndex = i;
                    fillAmountSList.push(order.params.amountS.toNumber());
                }
                else {
                    if (fillAmountSMax > rateAmountSList[i].toNumber()) {
                        if (order.params.buyNoMoreThanAmountB) {
                            fillAmountSList.push(rateAmountSList[i].toNumber());
                        }
                        else {
                            fillAmountSList.push(fillAmountSMax);
                        }
                    }
                    else {
                        fillAmountSList.push(fillAmountSMax);
                    }
                    smallestIndex = i - 1;
                }
            }
        }
        for (let i = 0; i < size; i++) {
            const ind = (smallestIndex + i) % size;
            const nextInd = (ind + 1) % size;
            const order = ring.orders[ind];
            const nextFillAmountSNumber = fillAmountSList[ind] * order.params.amountB.toNumber() / rateAmountSList[ind].toNumber();
            fillAmountSList[nextInd] = nextFillAmountSNumber;
        }
        let result = {};
        let fees = [];
        let balances = [];
        // caculate fees for each order. and assemble result.
        for (let i = 0; i < size; i++) {
            const nextInd = (i + 1) % size;
            const order = ring.orders[i];
            let feeItem = {};
            feeItem.fillS = fillAmountSList[i];
            if (0 == feeSelectionList[i]) {
                feeItem.feeLrc = order.params.lrcFee.toNumber();
                feeItem.feeS = 0;
                feeItem.feeB = 0;
            }
            else if (1 == feeSelectionList[i]) {
                if (order.params.buyNoMoreThanAmountB) {
                    feeItem.feeS = fillAmountSList[i] * order.params.amountS.toNumber() / rateAmountSList[i].toNumber() - fillAmountSList[i];
                    feeItem.feeS = feeItem.feeS * order.params.marginSplitPercentage / 100;
                    feeItem.feeB = 0;
                }
                else {
                    feeItem.feeS = 0;
                    feeItem.feeB = fillAmountSList[nextInd] - fillAmountSList[i] * order.params.amountB.toNumber() / order.params.amountS.toNumber();
                    feeItem.feeB = feeItem.feeB * order.params.marginSplitPercentage / 100;
                }
            }
            else {
                throw new Error("invalid fee selection value.");
            }
            fees.push(feeItem);
        }
        result.fees = fees;
        for (let i = 0; i < size; i++) {
            const order = ring.orders[i];
            const prevInd = this.getPrevIndex(i, size);
            let balanceItem = {};
            balanceItem.balanceS = order.params.amountS.toNumber() - fillAmountSList[i] - fees[i].feeS;
            balanceItem.balanceB = fillAmountSList[prevInd] - fees[i].feeB;
            balanceItem.feeSTotal = fees[i].feeS + fees[prevInd].feeB;
            balances.push(balanceItem);
        }
        result.balances = balances;
        //console.log("result:", result);
        return result;
    }
    getPrevIndex(i, size) {
        if (i <= 0)
            return size - 1;
        else
            return (i - 1) % size;
    }
}
exports.RingFactory = RingFactory;
;
//# sourceMappingURL=ring_factory.js.map