"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const _ = require("lodash");
const ethUtil = require("ethereumjs-util");
const promisify = require("es6-promisify");
const crypto_1 = require("./crypto");
const web3Instance = web3;
class Ring {
    constructor(owner, orders) {
        this.owner = owner;
        this.orders = orders;
    }
    isValidSignature() {
        if (_.isUndefined(this.v) || _.isUndefined(this.r) || _.isUndefined(this.s)) {
            throw new Error('Cannot call isValidSignature on unsigned order');
        }
        const ringHash = this.getRingHash();
        const msgHash = ethUtil.hashPersonalMessage(ringHash);
        try {
            const pubKey = ethUtil.ecrecover(msgHash, this.v, ethUtil.toBuffer(this.r), ethUtil.toBuffer(this.s));
            const recoveredAddress = ethUtil.bufferToHex(ethUtil.pubToAddress(pubKey));
            return recoveredAddress === this.owner;
        }
        catch (err) {
            return false;
        }
    }
    signAsync() {
        return __awaiter(this, void 0, void 0, function* () {
            const ringHash = this.getRingHash();
            //console.log("ring hash: ", ethUtil.bufferToHex(ringHash));
            const signature = yield promisify(web3Instance.eth.sign)(this.owner, ethUtil.bufferToHex(ringHash));
            const { v, r, s } = ethUtil.fromRpcSig(signature);
            this.v = v;
            this.r = ethUtil.bufferToHex(r);
            this.s = ethUtil.bufferToHex(s);
        });
    }
    getRingHash() {
        const size = this.orders.length;
        let vList = [];
        let rList = [];
        let sList = [];
        for (let i = 0; i < size; i++) {
            vList[i] = this.orders[i].params.v;
            rList[i] = this.orders[i].params.r;
            sList[i] = this.orders[i].params.s;
        }
        const ringHash = crypto_1.crypto.solSHA3([
            this.owner,
            this.xorReduce(vList),
            this.xorReduceStr(rList),
            this.xorReduceStr(sList),
        ]);
        return ringHash;
    }
    xorReduce(numberArr) {
        const n0 = numberArr[0];
        const tail = numberArr.slice(1);
        const intRes = tail.reduce((n1, n2) => n1 ^ n2, n0);
        return intRes;
    }
    xorReduceStr(strArr) {
        const s0 = strArr[0];
        const tail = strArr.slice(1);
        const strXor = (s1, s2) => {
            const buf1 = Buffer.from(s1.slice(2), "hex");
            const buf2 = Buffer.from(s2.slice(2), "hex");
            let res = Buffer.alloc(32);
            for (let i = 0; i < 32; i++) {
                res[i] = buf1[i] ^ buf2[i];
            }
            const strRes = ethUtil.bufferToHex(res);
            return strRes;
        };
        const reduceRes = tail.reduce((a, b) => strXor(a, b), s0);
        return Buffer.from(reduceRes.slice(2), "hex");
    }
}
exports.Ring = Ring;
//# sourceMappingURL=ring.js.map