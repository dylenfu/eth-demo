"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Artifacts {
    constructor(artifacts) {
        this.TokenRegistry = artifacts.require('TokenRegistry');
        this.RinghashRegistry = artifacts.require('RinghashRegistry');
        this.LoopringProtocolImpl = artifacts.require('LoopringProtocolImpl');
        this.TokenTransferDelegate = artifacts.require('TokenTransferDelegate');
        this.DummyToken = artifacts.require('test/DummyToken');
    }
}
exports.Artifacts = Artifacts;
//# sourceMappingURL=artifacts.js.map