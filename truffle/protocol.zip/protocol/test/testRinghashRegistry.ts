import { Artifacts } from '../util/artifacts';

contract('RinghashRegistry', (accounts: string[])=>{

  before(async () => {

  });

  describe('submitRinghash', () => {

    it('should be able to submit a ring hash', async () => {

    });

  });

});
