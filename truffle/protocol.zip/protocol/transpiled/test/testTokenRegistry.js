"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const artifacts_1 = require("../util/artifacts");
const { TokenRegistry, DummyToken, } = new artifacts_1.Artifacts(artifacts);
contract('TokenRegistry', (accounts) => {
    const owner = accounts[0];
    const user = accounts[1];
    let tokenRegistry;
    let lrcTokenAddr;
    let testTokenAddr;
    before(() => __awaiter(this, void 0, void 0, function* () {
        tokenRegistry = yield TokenRegistry.deployed();
        testTokenAddr = "0x8d01f9bcca92e63a1b2752b22d16e1962aa3c920";
        //lrcTokenAddr = await tokenRegistry.getAddressBySymbol("LRC");
    }));
    describe('owner', () => {
        it('should be able to register a token', () => __awaiter(this, void 0, void 0, function* () {
            yield tokenRegistry.registerToken(testTokenAddr, "TEST", { from: owner });
            const isRegistered = yield tokenRegistry.isTokenRegistered(testTokenAddr);
            assert.equal(isRegistered, true, 'token should be registered');
        }));
        it('should be able to unregister a token', () => __awaiter(this, void 0, void 0, function* () {
            let isRegistered = yield tokenRegistry.isTokenRegistered(testTokenAddr);
            let isRegisteredBySymbol = yield tokenRegistry.isTokenRegisteredBySymbol("TEST");
            assert.equal(isRegistered, true, 'token should be registered on start');
            assert.equal(isRegisteredBySymbol, true, 'token should be registered on start');
            yield tokenRegistry.unregisterToken(testTokenAddr, "TEST", { from: owner });
            isRegistered = yield tokenRegistry.isTokenRegistered(testTokenAddr);
            isRegisteredBySymbol = yield tokenRegistry.isTokenRegisteredBySymbol("TEST");
            assert.equal(isRegistered, false, 'token should be unregistered');
            assert.equal(isRegisteredBySymbol, false, 'token should be unregistered');
        }));
    });
    describe('any user', () => {
        it('should be able to check a token registered or not', () => __awaiter(this, void 0, void 0, function* () {
            const isRegistered = yield tokenRegistry.isTokenRegistered(testTokenAddr, { from: user });
            assert.equal(isRegistered, isRegistered, 'any one should be able to check token registered or not ');
        }));
    });
});
//# sourceMappingURL=testTokenRegistry.js.map